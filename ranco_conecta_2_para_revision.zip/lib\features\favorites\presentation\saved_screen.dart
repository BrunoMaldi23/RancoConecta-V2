import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/widgets/ranco_empty_state.dart';
import '../../../core/widgets/ranco_error_state.dart';
import '../../auth/application/auth_controller.dart';
import '../../businesses/presentation/business_card.dart';
import '../application/favorite_providers.dart';

class SavedScreen extends ConsumerWidget {
  const SavedScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authStateProvider);
    return auth.when(
      data: (user) {
        if (user == null) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const RancoEmptyState(
                    icon: Icons.bookmark_border,
                    title: 'Tus guardados',
                    message:
                        'Ingresa para guardar y encontrar negocios rápidamente.',
                  ),
                  FilledButton.icon(
                    onPressed: () => context.go('/sign-in'),
                    icon: const Icon(Icons.login),
                    label: const Text('Ingresar'),
                  ),
                ],
              ),
            ),
          );
        }
        final favorites = ref.watch(favoriteBusinessesProvider);
        return favorites.when(
          data: (items) {
            if (items.isEmpty) {
              return const RancoEmptyState(
                icon: Icons.bookmark_border,
                title: 'Sin favoritos',
                message:
                    'Guarda negocios desde el detalle para volver a ellos fácilmente.',
              );
            }
            return GridView.builder(
              padding: const EdgeInsets.all(20),
              gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                maxCrossAxisExtent: 360,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.92,
              ),
              itemCount: items.length,
              itemBuilder: (context, index) =>
                  BusinessCard(business: items[index]),
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stackTrace) => RancoErrorState(
            message: favoritesFailureMessage(error),
            onRetry: () => ref.invalidate(favoriteBusinessesProvider),
          ),
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stackTrace) =>
          const RancoErrorState(message: 'No pudimos leer la sesión.'),
    );
  }
}
