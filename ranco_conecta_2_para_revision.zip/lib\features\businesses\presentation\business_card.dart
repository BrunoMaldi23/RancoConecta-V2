import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/widgets/ranco_badge.dart';
import '../../../shared/models/business.dart';
import '../../../theme/ranco_tokens.dart';

class BusinessCard extends StatelessWidget {
  const BusinessCard({required this.business, super.key});

  final Business business;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final coverage =
        business.coverage.map((location) => location.name).take(2).join(', ');

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => context.go('/business/${business.id}'),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 96,
              width: double.infinity,
              color: colorScheme.primaryContainer,
              child: Icon(
                _iconForType(business.type),
                color: colorScheme.onPrimaryContainer,
                size: 34,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(RancoSpacing.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(
                          business.name,
                          style: Theme.of(context).textTheme.titleMedium,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (business.isVerified)
                        const RancoBadge(
                            label: 'Verificado', icon: Icons.verified_outlined),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(business.type.label,
                      style: Theme.of(context).textTheme.labelLarge),
                  if ((business.description ?? '').isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      business.description!,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                  if (coverage.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        const Icon(Icons.place_outlined, size: 16),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            coverage,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _iconForType(BusinessType type) {
    return switch (type) {
      BusinessType.service => Icons.handyman_outlined,
      BusinessType.commerce => Icons.storefront_outlined,
      BusinessType.gastronomy => Icons.restaurant_outlined,
      BusinessType.lodging => Icons.bed_outlined,
    };
  }
}
