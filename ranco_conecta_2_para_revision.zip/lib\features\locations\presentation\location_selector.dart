import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../shared/models/location.dart';
import '../application/location_providers.dart';

class LocationSelector extends ConsumerWidget {
  const LocationSelector({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locations = ref.watch(locationsProvider);
    final selected = ref.watch(selectedLocationProvider);

    return locations.when(
      data: (items) {
        final value = selected ?? _defaultLocation(items);
        return DropdownButtonFormField<Location?>(
          initialValue: value,
          isExpanded: true,
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.place_outlined),
            labelText: 'Localidad',
          ),
          items: [
            const DropdownMenuItem<Location?>(
              value: null,
              child: Text('Todas las localidades'),
            ),
            for (final location in items)
              DropdownMenuItem<Location?>(
                value: location,
                child: Text(location.name),
              ),
          ],
          onChanged: (location) =>
              ref.read(selectedLocationProvider.notifier).state = location,
        );
      },
      loading: () => const LinearProgressIndicator(),
      error: (error, stackTrace) => Text(locationFailureMessage(error)),
    );
  }

  Location? _defaultLocation(List<Location> locations) {
    if (locations.isEmpty) {
      return null;
    }
    return locations.firstWhere(
      (location) => location.slug == 'lago-ranco',
      orElse: () => locations.first,
    );
  }
}
