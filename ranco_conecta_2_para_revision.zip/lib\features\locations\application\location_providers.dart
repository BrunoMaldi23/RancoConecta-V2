import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/errors/app_failure.dart';
import '../../../shared/models/location.dart';
import '../data/location_repository.dart';

final locationsProvider = FutureProvider<List<Location>>((ref) async {
  final result =
      await ref.watch(locationRepositoryProvider).listActiveLocations();
  return result.when(
    success: (locations) => locations,
    failure: (failure) => throw failure,
  );
});

final selectedLocationProvider = StateProvider<Location?>((ref) => null);

String locationFailureMessage(Object error) {
  if (error is AppFailure) {
    return error.message;
  }
  return 'No pudimos cargar las localidades.';
}
