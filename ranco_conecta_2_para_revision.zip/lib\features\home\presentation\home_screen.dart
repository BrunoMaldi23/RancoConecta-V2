import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../config/app_config.dart';
import '../../../core/widgets/ranco_error_state.dart';
import '../../../core/widgets/ranco_skeleton.dart';
import '../../../features/businesses/application/business_providers.dart';
import '../../../features/businesses/presentation/business_card.dart';
import '../../../features/categories/application/category_providers.dart';
import '../../../features/locations/presentation/location_selector.dart';
import '../../../shared/models/category.dart';
import '../../../theme/ranco_tokens.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final config = ref.watch(appConfigProvider);
    final categories = ref.watch(categoriesProvider);
    final businesses = ref.watch(publishedBusinessesProvider);
    final textTheme = Theme.of(context).textTheme;
    final colorScheme = Theme.of(context).colorScheme;

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const LocationSelector(),
                const SizedBox(height: 20),
                Text(
                  'Ranco Conecta',
                  style: textTheme.headlineMedium
                      ?.copyWith(fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                const Text(
                    'Servicios, comercios y experiencias locales verificables en tu zona.'),
                const SizedBox(height: 20),
                TextField(
                  readOnly: true,
                  onTap: () => context.go('/explore'),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: '¿Qué necesitas encontrar?',
                  ),
                ),
                if (!config.hasSupabaseConfig) ...[
                  const SizedBox(height: 16),
                  Material(
                    color: colorScheme.tertiaryContainer,
                    borderRadius: BorderRadius.circular(RancoRadius.sm),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(
                        'Modo desarrollo: falta SUPABASE_URL o SUPABASE_PUBLISHABLE_KEY.',
                        style:
                            TextStyle(color: colorScheme.onTertiaryContainer),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
            child: Text('Categorías', style: textTheme.titleLarge),
          ),
        ),
        categories.when(
          data: (items) =>
              SliverToBoxAdapter(child: _CategoryStrip(categories: items)),
          loading: () => const SliverToBoxAdapter(
            child: Padding(
                padding: EdgeInsets.all(20), child: RancoSkeleton(height: 88)),
          ),
          error: (error, stackTrace) => SliverToBoxAdapter(
            child: RancoErrorState(
              message: failureMessage(error, 'No pudimos cargar categorías.'),
              onRetry: () => ref.invalidate(categoriesProvider),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
            child: Row(
              children: [
                Expanded(
                    child: Text('Publicados', style: textTheme.titleLarge)),
                TextButton(
                  onPressed: () => context.go('/explore'),
                  child: const Text('Ver todos'),
                ),
              ],
            ),
          ),
        ),
        businesses.when(
          data: (items) {
            if (items.isEmpty) {
              return const SliverToBoxAdapter(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child:
                      Text('Aún no hay prestadores publicados en esta zona.'),
                ),
              );
            }
            final visible = items.take(4).toList();
            return SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
              sliver: SliverGrid.builder(
                itemCount: visible.length,
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 360,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 0.92,
                ),
                itemBuilder: (context, index) =>
                    BusinessCard(business: visible[index]),
              ),
            );
          },
          loading: () => const SliverToBoxAdapter(
            child: Padding(
                padding: EdgeInsets.all(20), child: RancoSkeleton(height: 180)),
          ),
          error: (error, stackTrace) => SliverToBoxAdapter(
            child: RancoErrorState(
              message: businessFailureMessage(error),
              onRetry: () => ref.invalidate(publishedBusinessesProvider),
            ),
          ),
        ),
      ],
    );
  }
}

class _CategoryStrip extends ConsumerWidget {
  const _CategoryStrip({required this.categories});

  final List<Category> categories;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (categories.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(horizontal: 20),
        child: Text('Aún no hay categorías activas.'),
      );
    }
    return SizedBox(
      height: 96,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          final category = categories[index];
          return ActionChip(
            avatar: Icon(_iconFor(category.iconKey), size: 18),
            label: Text(category.name),
            onPressed: () {
              ref.read(selectedCategoryIdProvider.notifier).state = category.id;
              context.go('/explore');
            },
          );
        },
      ),
    );
  }

  IconData _iconFor(String key) {
    return switch (key) {
      'tools' => Icons.handyman_outlined,
      'store' => Icons.storefront_outlined,
      'restaurant' => Icons.restaurant_outlined,
      'bed' => Icons.bed_outlined,
      'truck' => Icons.local_shipping_outlined,
      'alert' => Icons.emergency_outlined,
      _ => Icons.place_outlined,
    };
  }
}
