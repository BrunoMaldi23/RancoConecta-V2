import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/errors/app_failure.dart';
import '../../../shared/models/business.dart';
import '../../locations/application/location_providers.dart';
import '../data/business_repository.dart';

final businessSearchQueryProvider = StateProvider<String>((ref) => '');
final selectedCategoryIdProvider = StateProvider<String?>((ref) => null);

final publishedBusinessesProvider = FutureProvider<List<Business>>((ref) async {
  final selectedLocation = ref.watch(selectedLocationProvider);
  final categoryId = ref.watch(selectedCategoryIdProvider);
  final search = ref.watch(businessSearchQueryProvider);
  final result =
      await ref.watch(businessRepositoryProvider).listPublishedBusinesses(
            BusinessQuery(
              categoryId: categoryId,
              locationId: selectedLocation?.id,
              searchQuery: search,
            ),
          );
  return result.when(
    success: (businesses) => businesses,
    failure: (failure) => throw failure,
  );
});

final businessDetailProvider =
    FutureProvider.family<Business, String>((ref, id) async {
  final result =
      await ref.watch(businessRepositoryProvider).getBusinessById(id);
  return result.when(
    success: (business) => business,
    failure: (failure) => throw failure,
  );
});

String businessFailureMessage(Object error) {
  if (error is AppFailure) {
    return error.message;
  }
  return 'No pudimos cargar los negocios.';
}
