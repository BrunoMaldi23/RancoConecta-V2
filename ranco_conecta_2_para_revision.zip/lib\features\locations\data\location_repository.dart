import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/errors/failure_mapper.dart';
import '../../../core/result/result.dart';
import '../../../features/auth/data/supabase_auth_repository.dart';
import '../../../shared/models/location.dart';
import 'location_dto.dart';

final locationRepositoryProvider = Provider<LocationRepository>((ref) {
  return SupabaseLocationRepository(ref.watch(supabaseClientProvider));
});

abstract interface class LocationRepository {
  Future<Result<List<Location>>> listActiveLocations();
}

class SupabaseLocationRepository implements LocationRepository {
  const SupabaseLocationRepository(this._client);

  final SupabaseClient? _client;

  @override
  Future<Result<List<Location>>> listActiveLocations() async {
    final client = _client;
    if (client == null) {
      return const Success([]);
    }
    try {
      final rows = await client
          .from('locations')
          .select()
          .eq('active', true)
          .order('sort_order');
      return Success(
          rows.map((row) => LocationDto.fromJson(row).toDomain()).toList());
    } catch (error) {
      return Failure(mapSupabaseFailure(error,
          fallbackMessage: 'No pudimos cargar las localidades.'));
    }
  }
}
