import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/widgets/ranco_error_state.dart';
import '../../auth/application/auth_controller.dart';
import '../../auth/data/supabase_auth_repository.dart';
import '../application/profile_providers.dart';

class AccountScreen extends ConsumerWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authStateProvider);
    return auth.when(
      data: (user) {
        if (user == null) {
          return const _GuestAccount();
        }
        final profile = ref.watch(currentProfileProvider);
        return profile.when(
          data: (profile) => ListView(
            padding: const EdgeInsets.all(20),
            children: [
              CircleAvatar(
                radius: 36,
                child: Text(
                  (profile.fullName ?? user.email ?? 'R')
                      .characters
                      .first
                      .toUpperCase(),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                profile.fullName ?? 'Sin nombre',
                style: Theme.of(context).textTheme.headlineSmall,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 4),
              Text(user.email ?? 'Sin email', textAlign: TextAlign.center),
              const SizedBox(height: 24),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.badge_outlined),
                  title: const Text('Rol'),
                  subtitle: Text(profile.role.label),
                ),
              ),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.verified_user_outlined),
                  title: const Text('Estado'),
                  subtitle: Text(_statusLabel(profile.accountStatus)),
                ),
              ),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.phone_outlined),
                  title: const Text('Teléfono'),
                  subtitle: Text(profile.phone?.isNotEmpty == true
                      ? profile.phone!
                      : 'No informado'),
                ),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => context.go('/account/edit'),
                icon: const Icon(Icons.edit_outlined),
                label: const Text('Editar perfil'),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () async {
                  await ref.read(authRepositoryProvider).signOut();
                  ref.invalidate(currentProfileProvider);
                },
                icon: const Icon(Icons.logout),
                label: const Text('Cerrar sesión'),
              ),
            ],
          ),
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stackTrace) => RancoErrorState(
            message: profileFailureMessage(error),
            onRetry: () => ref.invalidate(currentProfileProvider),
          ),
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stackTrace) => const RancoErrorState(
        message: 'No pudimos leer la sesión.',
      ),
    );
  }

  String _statusLabel(String status) {
    return switch (status) {
      'active' => 'Activa',
      'pending' => 'Pendiente',
      'suspended' => 'Suspendida',
      'blocked' => 'Bloqueada',
      'deleted' => 'Eliminada',
      _ => status,
    };
  }
}

class _GuestAccount extends StatelessWidget {
  const _GuestAccount();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 440),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Tu cuenta',
                  style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 8),
              const Text(
                'Ingresa para guardar favoritos, solicitar servicios y administrar tu perfil.',
              ),
              const SizedBox(height: 20),
              FilledButton.icon(
                onPressed: () => context.go('/sign-in'),
                icon: const Icon(Icons.login),
                label: const Text('Ingresar'),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () => context.go('/sign-up'),
                icon: const Icon(Icons.person_add_outlined),
                label: const Text('Crear cuenta'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
