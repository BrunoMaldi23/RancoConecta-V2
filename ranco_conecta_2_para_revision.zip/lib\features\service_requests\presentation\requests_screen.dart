import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../core/widgets/ranco_empty_state.dart';
import '../../../core/widgets/ranco_error_state.dart';
import '../../auth/application/auth_controller.dart';
import '../application/service_request_providers.dart';

class RequestsScreen extends ConsumerWidget {
  const RequestsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authStateProvider);
    return auth.when(
      data: (user) {
        if (user == null) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const RancoEmptyState(
                    icon: Icons.assignment_outlined,
                    title: 'Tus solicitudes',
                    message:
                        'Ingresa para crear y revisar solicitudes de servicio.',
                  ),
                  FilledButton.icon(
                    onPressed: () => context.go('/sign-in'),
                    icon: const Icon(Icons.login),
                    label: const Text('Ingresar'),
                  ),
                ],
              ),
            ),
          );
        }
        final requests = ref.watch(myRequestsProvider);
        return requests.when(
          data: (items) {
            if (items.isEmpty) {
              return const RancoEmptyState(
                icon: Icons.assignment_outlined,
                title: 'Sin solicitudes',
                message: 'Cuando solicites un servicio, aparecerá aquí.',
              );
            }
            return ListView.separated(
              padding: const EdgeInsets.all(20),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final request = items[index];
                return Card(
                  child: ListTile(
                    onTap: () => context.go('/requests/${request.id}'),
                    title: Text(request.publicCode),
                    subtitle: Text(
                        '${request.businessName ?? 'Solicitud abierta'} · ${request.subcategoryName}'),
                    trailing: Text(request.status.label),
                  ),
                );
              },
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (error, stackTrace) => RancoErrorState(
            message: requestFailureMessage(error),
            onRetry: () => ref.invalidate(myRequestsProvider),
          ),
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stackTrace) =>
          const RancoErrorState(message: 'No pudimos leer la sesión.'),
    );
  }
}

class RequestDetailScreen extends ConsumerWidget {
  const RequestDetailScreen({required this.requestId, super.key});

  final String requestId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final request = ref.watch(requestDetailProvider(requestId));
    final dateFormat = DateFormat.yMMMd('es');
    return Scaffold(
      appBar: AppBar(title: const Text('Solicitud')),
      body: request.when(
        data: (request) => ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text(request.publicCode,
                style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 8),
            Text(request.status.label),
            const SizedBox(height: 20),
            _DetailRow(
                label: 'Negocio',
                value: request.businessName ?? 'Solicitud abierta'),
            _DetailRow(label: 'Servicio', value: request.subcategoryName),
            _DetailRow(label: 'Urgencia', value: request.urgency.label),
            _DetailRow(
              label: 'Fecha deseada',
              value: request.desiredDate == null
                  ? 'No definida'
                  : dateFormat.format(request.desiredDate!),
            ),
            _DetailRow(
                label: 'Dirección',
                value: request.addressText ?? 'No informada'),
            const SizedBox(height: 20),
            Text('Descripción', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Text(request.description),
            const SizedBox(height: 24),
            Text('Timeline', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            const ListTile(
              leading: Icon(Icons.check_circle_outline),
              title: Text('Solicitud enviada'),
              subtitle: Text(
                  'Las siguientes etapas se habilitarán en próximos sprints.'),
            ),
          ],
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stackTrace) => RancoErrorState(
          message: requestFailureMessage(error),
          onRetry: () => ref.invalidate(requestDetailProvider(requestId)),
        ),
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  const _DetailRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
              width: 120,
              child:
                  Text(label, style: Theme.of(context).textTheme.labelLarge)),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}
