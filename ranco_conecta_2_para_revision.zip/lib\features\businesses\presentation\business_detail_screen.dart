import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/widgets/ranco_badge.dart';
import '../../../core/widgets/ranco_error_state.dart';
import '../../../features/auth/application/auth_controller.dart';
import '../../../features/favorites/application/favorite_providers.dart';
import '../../../features/favorites/data/favorites_repository.dart';
import '../../../shared/models/business.dart';
import '../application/business_hours.dart';
import '../application/business_providers.dart';

class BusinessDetailScreen extends ConsumerWidget {
  const BusinessDetailScreen({required this.businessId, super.key});

  final String businessId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final business = ref.watch(businessDetailProvider(businessId));
    return business.when(
      data: (business) => _BusinessDetail(business: business),
      loading: () =>
          const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (error, stackTrace) => Scaffold(
        body: RancoErrorState(
          message: businessFailureMessage(error),
          onRetry: () => ref.invalidate(businessDetailProvider(businessId)),
        ),
      ),
    );
  }
}

class _BusinessDetail extends ConsumerWidget {
  const _BusinessDetail({required this.business});

  final Business business;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favorite = ref.watch(isFavoriteProvider(business.id));
    final coverage =
        business.coverage.map((location) => location.name).join(', ');
    final openNow = isOpenNow(business.hours, DateTime.now());

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 220,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(business.name,
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              background: Container(
                color: Theme.of(context).colorScheme.primaryContainer,
                child: Icon(
                  Icons.storefront_outlined,
                  size: 64,
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                ),
              ),
            ),
            actions: [
              favorite.when(
                data: (isFavorite) => IconButton(
                  tooltip: isFavorite ? 'Quitar guardado' : 'Guardar',
                  onPressed: () => _toggleFavorite(context, ref, isFavorite),
                  icon:
                      Icon(isFavorite ? Icons.bookmark : Icons.bookmark_border),
                ),
                loading: () => const SizedBox.shrink(),
                error: (_, __) => const SizedBox.shrink(),
              ),
            ],
          ),
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList.list(
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    RancoBadge(label: business.type.label),
                    if (business.isVerified)
                      const RancoBadge(
                          label: 'Verificado', icon: Icons.verified_outlined),
                    RancoBadge(
                        label: openNow
                            ? 'Abierto ahora'
                            : 'Horario no disponible'),
                  ],
                ),
                const SizedBox(height: 16),
                if ((business.description ?? '').isNotEmpty)
                  Text(business.description!),
                const SizedBox(height: 20),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    if (business.whatsapp?.isNotEmpty == true)
                      FilledButton.icon(
                        onPressed: () => _launchWhatsApp(business.whatsapp!),
                        icon: const Icon(Icons.chat_outlined),
                        label: const Text('WhatsApp'),
                      ),
                    if (business.phone?.isNotEmpty == true)
                      OutlinedButton.icon(
                        onPressed: () => _launchPhone(business.phone!),
                        icon: const Icon(Icons.call_outlined),
                        label: const Text('Llamar'),
                      ),
                    FilledButton.tonalIcon(
                      onPressed: () => _requestService(context, ref),
                      icon: const Icon(Icons.assignment_add),
                      label: const Text('Solicitar servicio'),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                _Section(
                  title: 'Servicios',
                  child: business.services.isEmpty
                      ? const Text(
                          'Este negocio aún no informa servicios específicos.')
                      : Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            for (final service in business.services)
                              Chip(label: Text(service.subcategory.name)),
                          ],
                        ),
                ),
                _Section(
                  title: 'Cobertura',
                  child: Text(
                      coverage.isEmpty ? 'Cobertura no informada.' : coverage),
                ),
                _Section(
                  title: 'Horarios',
                  child: business.hours.isEmpty
                      ? const Text('Horarios no informados.')
                      : Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            for (final hour in business.hours)
                              Text(
                                  '${_dayLabel(hour.dayOfWeek)}: ${hour.isClosed ? 'Cerrado' : '${hour.openTime} - ${hour.closeTime}'}'),
                          ],
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _toggleFavorite(
      BuildContext context, WidgetRef ref, bool isFavorite) async {
    final user = ref.read(authStateProvider).valueOrNull;
    if (user == null) {
      context.go('/sign-in');
      return;
    }
    final repository = ref.read(favoritesRepositoryProvider);
    final result = isFavorite
        ? await repository.removeFavorite(business.id)
        : await repository.addFavorite(business.id);
    result.when(
      success: (_) {
        ref.invalidate(isFavoriteProvider(business.id));
        ref.invalidate(favoriteBusinessesProvider);
      },
      failure: (failure) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(failure.message)));
      },
    );
  }

  void _requestService(BuildContext context, WidgetRef ref) {
    final user = ref.read(authStateProvider).valueOrNull;
    if (user == null) {
      context.go('/sign-in');
      return;
    }
    context.go('/business/${business.id}/request');
  }

  Future<void> _launchPhone(String phone) async {
    await launchUrl(Uri(scheme: 'tel', path: phone.replaceAll(' ', '')));
  }

  Future<void> _launchWhatsApp(String phone) async {
    final digits = phone.replaceAll(RegExp(r'[^0-9+]'), '');
    await launchUrl(Uri.parse('https://wa.me/$digits'),
        mode: LaunchMode.externalApplication);
  }

  String _dayLabel(int day) {
    return switch (day) {
      1 => 'Lunes',
      2 => 'Martes',
      3 => 'Miércoles',
      4 => 'Jueves',
      5 => 'Viernes',
      6 => 'Sábado',
      7 => 'Domingo',
      _ => 'Día',
    };
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }
}
