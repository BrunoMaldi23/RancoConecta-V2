class Location {
  const Location({
    required this.id,
    required this.communeId,
    required this.name,
    required this.slug,
  });

  final String id;
  final String communeId;
  final String name;
  final String slug;
}
