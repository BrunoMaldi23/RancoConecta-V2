import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/widgets/ranco_empty_state.dart';
import '../../../core/widgets/ranco_error_state.dart';
import '../../../core/widgets/ranco_search_field.dart';
import '../../../core/widgets/ranco_skeleton.dart';
import '../../../features/businesses/application/business_providers.dart';
import '../../../features/businesses/presentation/business_card.dart';
import '../../../features/categories/application/category_providers.dart';
import '../../../features/locations/presentation/location_selector.dart';

class ExploreScreen extends ConsumerStatefulWidget {
  const ExploreScreen({super.key});

  @override
  ConsumerState<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends ConsumerState<ExploreScreen> {
  final _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final categories = ref.watch(categoriesProvider);
    final businesses = ref.watch(publishedBusinessesProvider);

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Explorar',
                    style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 16),
                RancoSearchField(
                  controller: _searchController,
                  hintText: 'Buscar por nombre o descripción',
                  onChanged: (value) => ref
                      .read(businessSearchQueryProvider.notifier)
                      .state = value,
                ),
                const SizedBox(height: 12),
                const LocationSelector(),
                const SizedBox(height: 12),
                categories.when(
                  data: (items) => Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      ChoiceChip(
                        label: const Text('Todas'),
                        selected: ref.watch(selectedCategoryIdProvider) == null,
                        onSelected: (_) => ref
                            .read(selectedCategoryIdProvider.notifier)
                            .state = null,
                      ),
                      for (final category in items)
                        ChoiceChip(
                          label: Text(category.name),
                          selected: ref.watch(selectedCategoryIdProvider) ==
                              category.id,
                          onSelected: (_) => ref
                              .read(selectedCategoryIdProvider.notifier)
                              .state = category.id,
                        ),
                    ],
                  ),
                  loading: () => const LinearProgressIndicator(),
                  error: (error, stackTrace) => Text(
                      failureMessage(error, 'No pudimos cargar categorías.')),
                ),
              ],
            ),
          ),
        ),
        businesses.when(
          data: (items) {
            if (items.isEmpty) {
              return const SliverFillRemaining(
                hasScrollBody: false,
                child: RancoEmptyState(
                  icon: Icons.storefront_outlined,
                  title: 'Sin negocios publicados',
                  message: 'Aún no hay prestadores publicados en esta zona.',
                ),
              );
            }
            return SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
              sliver: SliverGrid.builder(
                itemCount: items.length,
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 360,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 0.92,
                ),
                itemBuilder: (context, index) =>
                    BusinessCard(business: items[index]),
              ),
            );
          },
          loading: () => const SliverToBoxAdapter(
            child: Padding(
                padding: EdgeInsets.all(20), child: RancoSkeleton(height: 220)),
          ),
          error: (error, stackTrace) => SliverFillRemaining(
            hasScrollBody: false,
            child: RancoErrorState(
              message: businessFailureMessage(error),
              onRetry: () => ref.invalidate(publishedBusinessesProvider),
            ),
          ),
        ),
      ],
    );
  }
}
