import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/widgets/ranco_empty_state.dart';
import '../../../core/widgets/ranco_error_state.dart';
import '../../../core/widgets/ranco_search_field.dart';
import '../../../core/widgets/ranco_skeleton.dart';
import '../../../features/businesses/application/business_providers.dart';
import '../../../features/businesses/presentation/business_card.dart';
import '../../../features/categories/application/category_providers.dart';
import '../../../features/locations/presentation/location_selector.dart';

class ExploreScreen extends ConsumerStatefulWidget {
  const ExploreScreen({super.key});

  @override
  ConsumerState<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends ConsumerState<ExploreScreen> {
  final _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final categories = ref.watch(categoriesProvider);
    final businesses = ref.watch(publishedBusinessesProvider);
    final selectedCategory = ref.watch(selectedCategoryIdProvider);
    final colorScheme = Theme.of(context).colorScheme;

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Explorar', style: Theme.of(context).textTheme.headlineSmall),
                  const SizedBox(height: 4),
                  Text(
                    'Busca servicios, comercios y experiencias por nombre, categoría o localidad.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                        ),
                  ),
                  const SizedBox(height: 14),
                  RancoSearchField(
                    controller: _searchController,
                    hintText: '¿Qué estás buscando?',
                    onChanged: (value) =>
                        ref.read(businessSearchQueryProvider.notifier).state = value,
                  ),
                  const SizedBox(height: 10),
                  const LocationSelector(compact: true),
                  const SizedBox(height: 12),
                  categories.when(
                    data: (items) => SizedBox(
                      height: 38,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: items.length + 1,
                        separatorBuilder: (_, __) => const SizedBox(width: 8),
                        itemBuilder: (context, index) {
                          if (index == 0) {
                            return ChoiceChip(
                              label: const Text('Todas'),
                              selected: selectedCategory == null,
                              onSelected: (_) =>
                                  ref.read(selectedCategoryIdProvider.notifier).state = null,
                            );
                          }
                          final category = items[index - 1];
                          return ChoiceChip(
                            label: Text(category.name),
                            selected: selectedCategory == category.id,
                            onSelected: (_) =>
                                ref.read(selectedCategoryIdProvider.notifier).state = category.id,
                          );
                        },
                      ),
                    ),
                    loading: () => const LinearProgressIndicator(),
                    error: (error, stackTrace) => Text(
                      failureMessage(error, 'No pudimos cargar categorías.'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        businesses.when(
          data: (items) {
            if (items.isEmpty) {
              return SliverFillRemaining(
                hasScrollBody: false,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const RancoEmptyState(
                      compact: true,
                      icon: Icons.search_off_rounded,
                      title: 'Todavía no encontramos resultados',
                      message:
                          'Prueba cambiando la localidad, categoría o el texto de búsqueda.',
                    ),
                    OutlinedButton.icon(
                      onPressed: () {
                        _searchController.clear();
                        ref.read(businessSearchQueryProvider.notifier).state = '';
                        ref.read(selectedCategoryIdProvider.notifier).state = null;
                      },
                      icon: const Icon(Icons.restart_alt_rounded),
                      label: const Text('Limpiar filtros'),
                    ),
                    const SizedBox(height: 48),
                  ],
                ),
              );
            }

            return SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
              sliver: SliverList.separated(
                itemCount: items.length + 1,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  if (index == 0) {
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: Text(
                        '${items.length} ${items.length == 1 ? 'resultado' : 'resultados'}',
                        style: Theme.of(context).textTheme.labelLarge?.copyWith(
                              color: colorScheme.onSurfaceVariant,
                            ),
                      ),
                    );
                  }
                  return BusinessCard(business: items[index - 1]);
                },
              ),
            );
          },
          loading: () => const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 18),
              child: RancoSkeleton(height: 112),
            ),
          ),
          error: (error, stackTrace) => SliverFillRemaining(
            hasScrollBody: false,
            child: RancoErrorState(
              message: businessFailureMessage(error),
              onRetry: () => ref.invalidate(publishedBusinessesProvider),
            ),
          ),
        ),
      ],
    );
  }
}
