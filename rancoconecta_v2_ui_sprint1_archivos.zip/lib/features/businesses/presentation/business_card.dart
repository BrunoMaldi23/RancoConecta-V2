import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../shared/models/business.dart';
import '../../../theme/ranco_tokens.dart';

class BusinessCard extends StatelessWidget {
  const BusinessCard({required this.business, super.key});

  final Business business;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    final coverage = business.coverage.map((location) => location.name).take(2).join(', ');
    final serviceName = business.services.isNotEmpty
        ? business.services.first.subcategory.name
        : business.type.label;

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => context.go('/business/${business.id}'),
        child: Padding(
          padding: const EdgeInsets.all(RancoSpacing.md),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 68,
                height: 68,
                decoration: BoxDecoration(
                  color: colorScheme.primaryContainer.withValues(alpha: .8),
                  borderRadius: BorderRadius.circular(RancoRadius.sm),
                ),
                child: Icon(
                  _iconForType(business.type),
                  color: colorScheme.primary,
                  size: 29,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            business.name,
                            style: textTheme.titleMedium,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if (business.isVerified) ...[
                          const SizedBox(width: 6),
                          Icon(Icons.verified_rounded, size: 18, color: colorScheme.primary),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      serviceName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurfaceVariant,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    if (coverage.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(Icons.location_on_outlined, size: 15, color: colorScheme.onSurfaceVariant),
                          const SizedBox(width: 3),
                          Expanded(
                            child: Text(
                              coverage,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: textTheme.bodySmall?.copyWith(
                                color: colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Icon(Icons.chevron_right_rounded, color: colorScheme.onSurfaceVariant),
            ],
          ),
        ),
      ),
    );
  }

  IconData _iconForType(BusinessType type) {
    return switch (type) {
      BusinessType.service => Icons.handyman_outlined,
      BusinessType.commerce => Icons.storefront_outlined,
      BusinessType.gastronomy => Icons.restaurant_outlined,
      BusinessType.lodging => Icons.bed_outlined,
    };
  }
}
