import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../shared/models/location.dart';
import '../application/location_providers.dart';

class LocationSelector extends ConsumerWidget {
  const LocationSelector({
    this.compact = false,
    this.label = 'Localidad',
    super.key,
  });

  final bool compact;
  final String label;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final locations = ref.watch(locationsProvider);
    final selected = ref.watch(selectedLocationProvider);

    return locations.when(
      data: (items) {
        final value = selected ?? _defaultLocation(items);
        return DropdownButtonFormField<Location?>(
          initialValue: value,
          isExpanded: true,
          icon: const Icon(Icons.keyboard_arrow_down_rounded),
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.location_on_outlined),
            labelText: compact ? null : label,
            hintText: compact ? label : null,
            contentPadding: EdgeInsets.symmetric(
              horizontal: 12,
              vertical: compact ? 11 : 14,
            ),
          ),
          items: [
            const DropdownMenuItem<Location?>(
              value: null,
              child: Text('Todas las localidades'),
            ),
            for (final location in items)
              DropdownMenuItem<Location?>(
                value: location,
                child: Text(
                  location.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
          ],
          onChanged: (location) =>
              ref.read(selectedLocationProvider.notifier).state = location,
        );
      },
      loading: () => const SizedBox(
        height: 46,
        child: Center(child: LinearProgressIndicator()),
      ),
      error: (error, stackTrace) => Text(locationFailureMessage(error)),
    );
  }

  Location? _defaultLocation(List<Location> locations) {
    if (locations.isEmpty) {
      return null;
    }
    return locations.firstWhere(
      (location) => location.slug == 'lago-ranco',
      orElse: () => locations.first,
    );
  }
}
