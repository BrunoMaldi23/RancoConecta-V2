import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/widgets/ranco_error_state.dart';
import '../../../core/widgets/ranco_skeleton.dart';
import '../../../features/businesses/application/business_providers.dart';
import '../../../features/businesses/presentation/business_card.dart';
import '../../../features/categories/application/category_providers.dart';
import '../../../features/locations/presentation/location_selector.dart';
import '../../../shared/models/category.dart';
import '../../../theme/ranco_tokens.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final categories = ref.watch(categoriesProvider);
    final businesses = ref.watch(publishedBusinessesProvider);
    final textTheme = Theme.of(context).textTheme;
    final colorScheme = Theme.of(context).colorScheme;

    return CustomScrollView(
      slivers: [
        SliverToBoxAdapter(
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: colorScheme.primary,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'RC',
                          style: textTheme.labelLarge?.copyWith(
                            color: colorScheme.onPrimary,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Ranco Conecta',
                          style: textTheme.titleLarge,
                        ),
                      ),
                      IconButton(
                        tooltip: 'Explorar',
                        onPressed: () => context.go('/explore'),
                        icon: const Icon(Icons.tune_rounded),
                      ),
                    ],
                  ),
                  const SizedBox(height: 22),
                  Text(
                    'Encuentra lo que necesitas cerca de ti.',
                    style: textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Servicios, comercios y experiencias locales en un solo lugar.',
                    style: textTheme.bodyMedium?.copyWith(
                      color: colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 18),
                  TextField(
                    readOnly: true,
                    onTap: () => context.go('/explore'),
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.search_rounded),
                      hintText: '¿Qué necesitas encontrar?',
                      suffixIcon: Icon(Icons.arrow_forward_rounded),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const LocationSelector(compact: true),
                ],
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: _SectionHeader(
            title: 'Categorías',
            actionLabel: 'Ver todas',
            onAction: () => context.go('/explore'),
          ),
        ),
        categories.when(
          data: (items) => SliverToBoxAdapter(
            child: _CategoryGrid(categories: items),
          ),
          loading: () => const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 18),
              child: RancoSkeleton(height: 136),
            ),
          ),
          error: (error, stackTrace) => SliverToBoxAdapter(
            child: RancoErrorState(
              message: failureMessage(error, 'No pudimos cargar categorías.'),
              onRetry: () => ref.invalidate(categoriesProvider),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: _SectionHeader(
            title: 'Publicados',
            actionLabel: 'Ver todos',
            onAction: () => context.go('/explore'),
          ),
        ),
        businesses.when(
          data: (items) {
            if (items.isEmpty) {
              return SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 4),
                  child: _SoftEmptyCard(
                    icon: Icons.storefront_outlined,
                    title: 'Pronto verás negocios y prestadores aquí',
                    message:
                        'Cuando haya publicaciones activas para esta zona aparecerán en este espacio.',
                    buttonLabel: 'Explorar',
                    onPressed: () => context.go('/explore'),
                  ),
                ),
              );
            }
            final visible = items.take(4).toList();
            return SliverPadding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 6),
              sliver: SliverList.separated(
                itemCount: visible.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, index) =>
                    BusinessCard(business: visible[index]),
              ),
            );
          },
          loading: () => const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 18),
              child: RancoSkeleton(height: 112),
            ),
          ),
          error: (error, stackTrace) => SliverToBoxAdapter(
            child: RancoErrorState(
              message: businessFailureMessage(error),
              onRetry: () => ref.invalidate(publishedBusinessesProvider),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 10),
            child: _ActionCard(
              icon: Icons.assignment_add_outlined,
              title: '¿Necesitas un servicio?',
              message:
                  'Encuentra un prestador y envía una solicitud directamente desde su perfil.',
              buttonLabel: 'Buscar prestadores',
              onPressed: () => context.go('/explore'),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
            child: _ActionCard(
              icon: Icons.storefront_outlined,
              title: '¿Ofreces servicios o tienes un negocio?',
              message:
                  'Crea tu cuenta y prepara tu perfil para aparecer en Ranco Conecta.',
              buttonLabel: 'Crear cuenta',
              onPressed: () => context.go('/sign-up'),
              outlined: true,
            ),
          ),
        ),
      ],
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({
    required this.title,
    required this.actionLabel,
    required this.onAction,
  });

  final String title;
  final String actionLabel;
  final VoidCallback onAction;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 22, 10, 10),
      child: Row(
        children: [
          Expanded(
            child: Text(title, style: Theme.of(context).textTheme.titleLarge),
          ),
          TextButton(onPressed: onAction, child: Text(actionLabel)),
        ],
      ),
    );
  }
}

class _CategoryGrid extends ConsumerWidget {
  const _CategoryGrid({required this.categories});

  final List<Category> categories;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (categories.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(horizontal: 18),
        child: _SoftEmptyCard(
          icon: Icons.grid_view_rounded,
          title: 'Aún no hay categorías activas',
          message: 'Las categorías aparecerán aquí cuando estén disponibles.',
        ),
      );
    }

    final visible = categories.take(6).toList();
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final columns = constraints.maxWidth >= 720 ? 3 : 2;
          final spacing = 10.0;
          final width = (constraints.maxWidth - spacing * (columns - 1)) / columns;

          return Wrap(
            spacing: spacing,
            runSpacing: spacing,
            children: [
              for (final category in visible)
                SizedBox(
                  width: width,
                  child: _CategoryTile(
                    category: category,
                    onTap: () {
                      ref.read(selectedCategoryIdProvider.notifier).state = category.id;
                      context.go('/explore');
                    },
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _CategoryTile extends StatelessWidget {
  const _CategoryTile({required this.category, required this.onTap});

  final Category category;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Material(
      color: colorScheme.surfaceContainerLowest,
      borderRadius: BorderRadius.circular(RancoRadius.md),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(RancoRadius.md),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(RancoRadius.md),
            border: Border.all(color: colorScheme.outlineVariant.withValues(alpha: .8)),
          ),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: colorScheme.primaryContainer.withValues(alpha: .75),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(_iconFor(category.iconKey), size: 20, color: colorScheme.primary),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  category.name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.labelLarge,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SoftEmptyCard extends StatelessWidget {
  const _SoftEmptyCard({
    required this.icon,
    required this.title,
    required this.message,
    this.buttonLabel,
    this.onPressed,
  });

  final IconData icon;
  final String title;
  final String message;
  final String? buttonLabel;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(RancoRadius.md),
        border: Border.all(color: colorScheme.outlineVariant.withValues(alpha: .8)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: colorScheme.primaryContainer.withValues(alpha: .7),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: colorScheme.primary, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  message,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: colorScheme.onSurfaceVariant,
                      ),
                ),
                if (buttonLabel != null && onPressed != null) ...[
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: onPressed,
                    style: TextButton.styleFrom(padding: EdgeInsets.zero),
                    child: Text(buttonLabel!),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.title,
    required this.message,
    required this.buttonLabel,
    required this.onPressed,
    this.outlined = false,
  });

  final IconData icon;
  final String title;
  final String message;
  final String buttonLabel;
  final VoidCallback onPressed;
  final bool outlined;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: outlined
            ? colorScheme.surfaceContainerLowest
            : colorScheme.primaryContainer.withValues(alpha: .55),
        borderRadius: BorderRadius.circular(RancoRadius.lg),
        border: Border.all(
          color: outlined
              ? colorScheme.outlineVariant
              : colorScheme.primary.withValues(alpha: .12),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: colorScheme.primary),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  message,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: colorScheme.onSurfaceVariant,
                      ),
                ),
                const SizedBox(height: 10),
                outlined
                    ? OutlinedButton(onPressed: onPressed, child: Text(buttonLabel))
                    : FilledButton(onPressed: onPressed, child: Text(buttonLabel)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

IconData _iconFor(String key) {
  return switch (key) {
    'tools' => Icons.handyman_outlined,
    'store' => Icons.storefront_outlined,
    'restaurant' => Icons.restaurant_outlined,
    'bed' => Icons.bed_outlined,
    'truck' => Icons.local_shipping_outlined,
    'alert' => Icons.emergency_outlined,
    _ => Icons.place_outlined,
  };
}
